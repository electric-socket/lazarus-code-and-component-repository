#!/bin/sh
lazdir=~/lazarus
if ! [ -e $lazdir ] 
then
  lazdir=/usr/local/share/lazarus
fi
$lazdir/lazbuild -d --ws=carbon tests/TestFlexEdit/project1.lpi
$lazdir/lazbuild -d --ws=carbon tests/TestLabel/project1.lpi
$lazdir/lazbuild -d --ws=carbon tests/TestRLbl/project1.lpi
$lazdir/lazbuild -d --ws=carbon tests/TestSimpField/project1.lpi
$lazdir/lazbuild -d --ws=carbon tests/TestSpinner/project1.lpi
$lazdir/lazbuild -d --ws=carbon tests/TestTable/project1.lpi
$lazdir/lazbuild -d --ws=carbon tests/TestTblEdits/project1.lpi
$lazdir/lazbuild -d --ws=carbon tests/TestURL/project1.lpi
$lazdir/lazbuild -d --ws=carbon tests/TestVLB/project1.lpi
$lazdir/lazbuild -d --ws=carbon tests/TestCalendar/project1.lpi
