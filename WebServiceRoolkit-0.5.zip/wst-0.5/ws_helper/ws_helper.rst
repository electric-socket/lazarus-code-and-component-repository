
# hash value = 13585
ws_helper.sversion='2.1'


# hash value = 71138986
ws_helper.susage='ws_helper [-p] [-b] [-i] [-oPATH] inputFilename'#13#10' '+
' -p  Generate service proxy'#13#10'  -b  Generate service binder'#13#10' '+
' -i  Generate service minimal implementation'#13#10'  -o  PATH  Output d'+
'irectory'#13#10

# hash value = 89842783
ws_helper.scopyright='ws_helper, Web Service Toolkit 2.2 Copyright (c) 20'+
'06 by Inoussa OUEDRAOGO'

