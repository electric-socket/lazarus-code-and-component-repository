The is the source directory of the bluetoothlaz package.
The package and examples are licensed under the modified LGPL. See the headers
of the the files.

At the moment it only supports linux.

Prerequisites:

For linux you need the BlueZ devel package.
Under ubuntu/debian it is called: libbluetooth-dev
For example:
  sudo apt-get install libbluetooth-dev

There is an example showing the access of a wii-remote.

