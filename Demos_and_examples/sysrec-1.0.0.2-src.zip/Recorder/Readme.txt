Description: Video Capturing and Processing Application

Version: 1.0.0.2

Author: Razvan Adrian Bogdan

License: 
-  The vfw unit is licensed MPL and you can download it from 
   delphi-jedi, http://www.delphi-jedi.org/
   However it needs a few modifications, see included unit for 
   FPC detecting directives like {$IFDEF FPC} or {$IFNDEF FPC}

-  The application itself can be used under Lazarus modified LGPL or MPL

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
