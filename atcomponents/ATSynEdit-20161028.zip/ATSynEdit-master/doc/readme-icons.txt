IDE icons from
Icon Pack: Chalkwork HTML
Designer: Dave Shea 
http://www.mezzoblue.com/icons/chalkwork/html/
