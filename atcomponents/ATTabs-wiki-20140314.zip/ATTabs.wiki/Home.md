class TATTabs
=============

There's no designer support for tabs. Create objects of this class by [code like this](create).

- [properties](props)
- [events](events)
- [methods](methods)
