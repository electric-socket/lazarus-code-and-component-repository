def Add(a, b):
  return a + b
