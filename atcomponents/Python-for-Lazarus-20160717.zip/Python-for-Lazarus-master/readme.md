This is P4D fork for Lazarus, supports Win/Linux/MacOSX (both x32/x64).
See my article about sample app:

http://wiki.freepascal.org/Using_Python_in_Lazarus_on_Windows/Linux

