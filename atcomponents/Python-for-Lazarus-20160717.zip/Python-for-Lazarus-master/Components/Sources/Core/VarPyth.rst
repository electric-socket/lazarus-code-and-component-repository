
# hash value = 61888190
varpyth.smultidimensionalpropsnotsupported='Multi-dimensional sequences o'+
'r mappings are not supported in Python'


# hash value = 209853316
varpyth.scantconvertarg='Can'#39't convert argument #%d of %s into a Pyth'+
'on object'


# hash value = 198061570
varpyth.sbothoperandsofintdividemustbeintegers='Both operands of an integ'+
'er division must be of type integer'


# hash value = 229549924
varpyth.scantconvertkeytopythonobject='Can'#39't convert Key into a Pytho'+
'n object'


# hash value = 68458372
varpyth.scantconvertvaluetopythonobject='Can'#39't convert Value into a P'+
'ython object'


# hash value = 232876276
varpyth.scantcreatenewsequenceobject='Can'#39't create a new sequence obj'+
'ect'


# hash value = 196548996
varpyth.sexpectedpythonvariant='Expected a Python variant'

