Controls for Lazarus 

* ATButton: http://wiki.freepascal.org/ATButton
* ATListbox: http://wiki.freepascal.org/ATListbox
* ATLinkLabel: http://wiki.freepascal.org/ATLinkLabel

Lazarus 1.4.0.
Tested on Win/Linux/OSX.
