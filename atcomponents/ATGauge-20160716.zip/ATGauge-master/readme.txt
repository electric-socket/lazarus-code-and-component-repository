Gauge for Lazarus. Looks like D7 one. 

- now all "kinds" are done.
- flicker free (uses temp bitmap). 
- added color of border.
- paints text with fixed color (D7 merged color to forecolor/backcolor).

Lazarus: 1.4.0.
Tested: Linux gtk2.

