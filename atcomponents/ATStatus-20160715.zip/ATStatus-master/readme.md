ATStatusBar
===========

Delphi/Lazarus component for lite statusbar (not OS-themed).  

Sample

![img](screenshot.png?raw=true)

Doc
===

Documentation is at "Wiki" page of github.
