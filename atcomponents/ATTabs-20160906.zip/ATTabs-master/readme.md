ATTabs
======

Delphi/Lazarus component for lite tabs. 
OS independant (custom drawn).

Image:

![img](img/demo.png?raw=true)

Documentation is at the Wiki page of github.
