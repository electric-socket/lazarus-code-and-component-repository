TFormStorage component for Lazarus
Written by Olivier Guilbaud.

This component save the Hight,With,Left and Top properties of Owner form in XML file.
In this file you can add all defined (and implemented) properites of Child component. For this, 
you must set the "Properties" FormStorage property with this syntax :

Button1.Caption
CheckBoox1.Checked

Her you save the Caption property of Button1 and Checked of Checkbox1.

See FormStorage.pp for Licence and history
