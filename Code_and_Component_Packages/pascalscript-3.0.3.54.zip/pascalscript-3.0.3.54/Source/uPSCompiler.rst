
# hash value = 133898084
upscompiler.rps_onuseeventonly='This function can only be called from wit'+
'hin the OnUses event'


# hash value = 133726723
upscompiler.rps_unabletoregisterfunction='Unable to register function %s'


# hash value = 124961539
upscompiler.rps_unabletoregisterconst='Unable to register constant %s'


# hash value = 197391827
upscompiler.rps_invalidtypeforvar='Invalid type for variable %s'


# hash value = 174098501
upscompiler.rps_invalidtype='Invalid Type'


# hash value = 96608195
upscompiler.rps_unabletoregistertype='Unable to register type %s'


# hash value = 160732723
upscompiler.rps_unknowninterface='Unknown interface: %s'


# hash value = 243449576
upscompiler.rps_constantvaluemismatch='Constant Value Type Mismatch'


# hash value = 143578244
upscompiler.rps_constantvaluenotassigned='Constant Value is not assigned'


# hash value = 5020002
upscompiler.rps_error='Error'


# hash value = 42229079
upscompiler.rps_unknownidentifier='Unknown identifier '#39'%s'#39

# hash value = 205240004
upscompiler.rps_identifierexpected='Identifier expected'


# hash value = 201893234
upscompiler.rps_commenterror='Comment error'


# hash value = 214370594
upscompiler.rps_stringerror='String error'


# hash value = 73926626
upscompiler.rps_charerror='Char error'


# hash value = 266126306
upscompiler.rps_syntaxerror='Syntax error'


# hash value = 209774597
upscompiler.rps_eof='Unexpected end of file'


# hash value = 74981748
upscompiler.rps_semicolonexpected='Semicolon ('#39';'#39') expected'


# hash value = 76122852
upscompiler.rps_beginexpected=#39'BEGIN'#39' expected'


# hash value = 241633300
upscompiler.rps_periodexpected='period ('#39'.'#39') expected'


# hash value = 91758807
upscompiler.rps_duplicateident='Duplicate identifier '#39'%s'#39

# hash value = 60037236
upscompiler.rps_colonexpected='colon ('#39':'#39') expected'


# hash value = 15644167
upscompiler.rps_unknowntype='Unknown type '#39'%s'#39

# hash value = 176602948
upscompiler.rps_closeroundexpected='Close round expected'


# hash value = 212205032
upscompiler.rps_typemismatch='Type mismatch'


# hash value = 33467641
upscompiler.rps_internalerror='Internal error (%s)'


# hash value = 71774820
upscompiler.rps_assignmentexpected='Assignment expected'


# hash value = 63639796
upscompiler.rps_thenexpected=#39'THEN'#39' expected'


# hash value = 83508308
upscompiler.rps_doexpected=#39'DO'#39' expected'


# hash value = 126680868
upscompiler.rps_noresult='No result'


# hash value = 100643796
upscompiler.rps_openroundexpected='open round ('#39'('#39')expected'


# hash value = 12658804
upscompiler.rps_commaexpected='comma ('#39','#39') expected'


# hash value = 66731092
upscompiler.rps_toexpected=#39'TO'#39' expected'


# hash value = 98717396
upscompiler.rps_isexpected='is ('#39'='#39') expected'


# hash value = 55786580
upscompiler.rps_ofexpected=#39'OF'#39' expected'


# hash value = 11605748
upscompiler.rps_closeblockexpected='Close block('#39']'#39') expected'


# hash value = 142956164
upscompiler.rps_variableexpected='Variable Expected'


# hash value = 107963588
upscompiler.rps_stringexpected='String Expected'


# hash value = 88948420
upscompiler.rps_endexpected=#39'END'#39' expected'


# hash value = 81636180
upscompiler.rps_unsetlabel='Label '#39'%s'#39' not set'


# hash value = 55666224
upscompiler.rps_notinloop='Not in a loop'


# hash value = 174380128
upscompiler.rps_invalidjump='Invalid jump'


# hash value = 109562420
upscompiler.rps_openblockexpected='Open Block ('#39'['#39') expected'


# hash value = 92657337
upscompiler.rps_writeonlyproperty='Write-only property'


# hash value = 180226441
upscompiler.rps_readonlyproperty='Read-only property'


# hash value = 222656836
upscompiler.rps_classtypeexpected='Class type expected'


# hash value = 159100767
upscompiler.rps_dividebyzero='Divide by Zero'


# hash value = 172597698
upscompiler.rps_matherror='Math Error'


# hash value = 240766259
upscompiler.rps_unsatisfiedforward='Unsatisfied Forward %s'


# hash value = 265995096
upscompiler.rps_forwardparametermismatch='Forward Parameter Mismatch'


# hash value = 128541971
upscompiler.rps_invalidnumberofparameter='Invalid number of parameters'


# hash value = 205443058
upscompiler.rps_unknownerror='Unknown error'


# hash value = 323668
upscompiler.rps_hint='Hint'


# hash value = 121447364
upscompiler.rps_variablenotused='Variable '#39'%s'#39' never used'


# hash value = 88925716
upscompiler.rps_functionnotused='Function '#39'%s'#39' never used'


# hash value = 163826484
upscompiler.rps_unknownhint='Unknown hint'


# hash value = 227102743
upscompiler.rps_warning='Warning'


# hash value = 176522723
upscompiler.rps_calculationalwaysevaluatesto='Calculation always evaluate'+
's to %s'


# hash value = 119417252
upscompiler.rps_isnotneeded='%s is not needed'


# hash value = 58344270
upscompiler.rps_abstractclass='Abstract Class Construction'


# hash value = 266327143
upscompiler.rps_unknownwarning='Unknown warning'


# hash value = 143011113
upscompiler.rps_notarrayproperty='Not an array property'


# hash value = 251722649
upscompiler.rps_notproperty='Not a property'


# hash value = 235866601
upscompiler.rps_unknownproperty='Unknown Property'

