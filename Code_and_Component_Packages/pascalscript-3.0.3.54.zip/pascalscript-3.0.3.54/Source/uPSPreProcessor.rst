
# hash value = 142863175
upspreprocessor.rps_toomanynestedinclude='Too many nested include files w'+
'hile processing '#39'%s'#39' from '#39'%s'#39

# hash value = 95661911
upspreprocessor.rps_includenotfound='Unable to find file '#39'%s'#39' use'+
'd from '#39'%s'#39

# hash value = 223970452
upspreprocessor.rps_definetoomanyparameters='Too many parameters at %d:%d'+


# hash value = 109732388
upspreprocessor.rps_noifdefforendif='No IFDEF for ENDIF at %d:%d'


# hash value = 119456692
upspreprocessor.rps_noifdefforelse='No IFDEF for ELSE at %d:%d'


# hash value = 200305204
upspreprocessor.rps_elsetwice='Can'#39't use ELSE twice at %d:%d'


# hash value = 11441604
upspreprocessor.rps_unknowncompilerdirective='Unknown compiler directives'+
' at %d:%d'


# hash value = 45966036
upspreprocessor.rps_definenotclosed='Define not closed'

