
# hash value = 126285180
upsc_dll.rps_invalid_external='Invalid External'


# hash value = 156316334
upsc_dll.rps_invalidcallingconvention='Invalid Calling Convention'

