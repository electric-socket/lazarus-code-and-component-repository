
# hash value = 18667125
upsdebugger.rps_expectedreturnaddressstackbase='Expected return address a'+
't stack base'

