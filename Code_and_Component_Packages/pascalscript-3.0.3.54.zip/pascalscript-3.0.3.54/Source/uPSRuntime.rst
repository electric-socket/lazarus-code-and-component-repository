
# hash value = 208539682
upsruntime.rps_unknownidentifier='Unknown Identifier'


# hash value = 80217379
upsruntime.rps_exception='Exception: %s'


# hash value = 97013661
upsruntime.rps_invalid='[Invalid]'


# hash value = 21798450
upsruntime.rps_noerror='No Error'


# hash value = 67877587
upsruntime.rps_cannotimport='Cannot Import %s'


# hash value = 174098501
upsruntime.rps_invalidtype='Invalid Type'


# hash value = 197134866
upsruntime.rps_internalerror='Internal error'


# hash value = 19091618
upsruntime.rps_invalidheader='Invalid Header'


# hash value = 45010885
upsruntime.rps_invalidopcode='Invalid Opcode'


# hash value = 130429570
upsruntime.rps_invalidopcodeparameter='Invalid Opcode Parameter'


# hash value = 156511267
upsruntime.rps_nomainproc='no Main Proc'


# hash value = 264240789
upsruntime.rps_outofglobalvarsrange='Out of Global Vars range'


# hash value = 9165813
upsruntime.rps_outofprocrange='Out of Proc Range'


# hash value = 221520261
upsruntime.rps_outofrange='Out Of Range'


# hash value = 7259669
upsruntime.rps_outofstackrange='Out Of Stack Range'


# hash value = 212205544
upsruntime.rps_typemismatch='Type Mismatch'


# hash value = 212002917
upsruntime.rps_unexpectedeof='Unexpected End Of File'


# hash value = 212154738
upsruntime.rps_versionerror='Version error'


# hash value = 159100255
upsruntime.rps_dividebyzero='divide by Zero'


# hash value = 174694850
upsruntime.rps_matherror='Math error'


# hash value = 233650179
upsruntime.rps_couldnotcallproc='Could not call proc'


# hash value = 88666933
upsruntime.rps_outofrecordrange='Out of Record Fields Range'


# hash value = 223865038
upsruntime.rps_nullpointerexception='Null Pointer Exception'


# hash value = 263734082
upsruntime.rps_nullvarianterror='Null variant error'


# hash value = 67007305
upsruntime.rps_outofmemory='Out Of Memory'


# hash value = 178728388
upsruntime.rps_interfacenotsupported='Interface not supported'


# hash value = 205443058
upsruntime.rps_unknownerror='Unknown error'


# hash value = 10820389
upsruntime.rps_invalidvariable='Invalid variable'


# hash value = 104077865
upsruntime.rps_invalidarray='Invalid array'


# hash value = 104123688
upsruntime.rps_oleerror='OLE error %.8x'


# hash value = 50829669
upsruntime.rps_unknownprocedure='Unknown procedure'


# hash value = 234350531
upsruntime.rps_notenoughparameters='Not enough parameters'


# hash value = 182837442
upsruntime.rps_invalidparameter='Invalid parameter'


# hash value = 183154467
upsruntime.rps_toomanyparameters='Too many parameters'


# hash value = 135634757
upsruntime.rps_outofstringrange='Out of string range'


# hash value = 240744133
upsruntime.rps_cannotcastinterface='Cannot cast an interface'


# hash value = 258636600
upsruntime.rps_capacitylength='Capacity < Length'


# hash value = 266667179
upsruntime.rps_canonlysendlastitem='Can only remove last item from stack'


# hash value = 238466965
upsruntime.rps_nilinterfaceexception='Nil interface'


# hash value = 68798612
upsruntime.rps_unknownmethod='Unknown method'

