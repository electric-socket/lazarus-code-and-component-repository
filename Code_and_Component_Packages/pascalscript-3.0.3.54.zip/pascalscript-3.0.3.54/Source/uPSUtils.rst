
# hash value = 103921444
upsutils.rps_invalidfloat='Invalid float'

