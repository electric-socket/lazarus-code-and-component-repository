
# hash value = 4874613
stconst.stscfalsestrings='FALSE'


# hash value = 366485
stconst.stsctruestrings='TRUE'


# hash value = 219531988
stconst.stscnofilekeys='No Ini File or Primary Key specified'


# hash value = 80348580
stconst.stscinvalidpkeys='Invalid primary key specified'


# hash value = 228329027
stconst.stscnowin32ss='RegIni Class not supported under Win32s'


# hash value = 133703508
stconst.stsccreatekeyfails='Failed to create key\nError Code: %d'


# hash value = 134596436
stconst.stscopenkeyfails='Failed to open key\nError Code: %d'


# hash value = 65143589
stconst.stsciniwritefails='Failed to write value to INI file'


# hash value = 174801140
stconst.stscregwritefails='Failed to write value to Registry\nError Code:'+
' %d'


# hash value = 179589508
stconst.stscnokeynames='No key name specified'


# hash value = 260898740
stconst.stscquerykeyfails='Unable to query specified key\nError Code: %d'


# hash value = 132153924
stconst.stscenumkeyfails='Unable to enumerate key\nError Code: %d'


# hash value = 223552228
stconst.stscenumvaluefails='Unable to enumerate value\nError Code: %d'


# hash value = 105613701
stconst.stscinideletefails='Unable to delete section from INI file'


# hash value = 84775385
stconst.stsckeyhassubkeyss='Can not delete key which has subkeys (%d)'


# hash value = 121666564
stconst.stscdeletekeyfails='Unable to delete key\nError Code: %d'


# hash value = 154355061
stconst.stscinidelvaluefails='Unable to delete value from INI file'


# hash value = 128519604
stconst.stscregdelvaluefails='Unable to delete value from key\nError Code'+
': %d'


# hash value = 97476355
stconst.stscoutputfileexistss='Output file exists'


# hash value = 69213870
stconst.stscfilehasextensions='File name can not have an extension'


# hash value = 44821732
stconst.stscsavekeyfails='Unable to save key\nError Code: %d'


# hash value = 259211571
stconst.stscno16bitsupports='Function not supported in 16-bit application'+
's'


# hash value = 221243333
stconst.stsccantfindinputfiles='Can not find input file'


# hash value = 230980916
stconst.stscloadkeyfails='Unable to load key\nError Code: %d'


# hash value = 72872180
stconst.stscunloadkeyfails='Unable to unload key\nErrorCode: %d'


# hash value = 211043949
stconst.stscnotwinntplatforms='Function not supported on this platform'


# hash value = 220924217
stconst.stscbadoptionskeycombos='Selection options incompatible\nwith spe'+
'cified primary key'


# hash value = 210884964
stconst.stscrestorekeyfails='Unable to restore key\nError Code: %d'


# hash value = 52357476
stconst.stscreplacekeyfails='Unable to replace key\nError Code: %d'


# hash value = 97224707
stconst.stscnoinifilesupports='Function not supported on INI files'


# hash value = 131806494
stconst.stscremotekeyisopens='Remote key already open'


# hash value = 234793556
stconst.stscconnectremotekeyfails='Unable to connect to remote registry k'+
'ey\nError Code: %d'


# hash value = 145726105
stconst.stsccloseremotekeyfails='Unable to close remote registry key'


# hash value = 181052041
stconst.stscflushkeyfails='Unable to flush specified key'


# hash value = 196013204
stconst.stscbufferdatasizesdifs='Buffer size differs from data size\nBuff'+
'er: %d   Data: %d'


# hash value = 55609876
stconst.stsckeyisemptynotexistss='Specified Key is empty or does not exis'+
't'


# hash value = 151200340
stconst.stscgetsecurityfails='Failed to Get Security Information\nError C'+
'ode: %d'


# hash value = 159015508
stconst.stscsetsecurityfails='Failed to Set Security Information\nError C'+
'ode: %d'


# hash value = 113517972
stconst.stscbytearraytoolarges='Size of byte array exceeds limit'


# hash value = 263142505
stconst.stscqueryvaluefails='Unable to query value in key'


# hash value = 197580612
stconst.stscnovaluenamespecifieds='No Value Name specified'


# hash value = 35236644
stconst.stscnocompares='Compare property must be set'


# hash value = 166628020
stconst.stscbadtypes='An incompatible class is passed to a method'


# hash value = 235133922
stconst.stscbadsizes='Bad size parameter'


# hash value = 228227925
stconst.stscdupnodes='Attempt to add duplicate node to TStTree'


# hash value = 98460565
stconst.stscbadindexs='Index is out of range'


# hash value = 130960552
stconst.stscbadwinmodes='Requires enhanced mode operation for Windows 3.1'+
'x'


# hash value = 93722820
stconst.stscunknownclasss='Container class name %s read from stream is un'+
'registered'


# hash value = 100414644
stconst.stscunknownnodeclasss='Node class name %s read from stream is unr'+
'egistered'


# hash value = 122296292
stconst.stscnostoredatas='Container'#39's StoreData property is unassigne'+
'd'


# hash value = 197143060
stconst.stscnoloaddatas='Container'#39's LoadData property is unassigned'


# hash value = 59158083
stconst.stscwrongclasss='Class name on stream differs from object'#39's c'+
'lass'


# hash value = 146219779
stconst.stscwrongnodeclasss='Node class name on stream differs from objec'+
't'#39's node class'


# hash value = 36589799
stconst.stscbadcompares='Unable to assign this compare function now'


# hash value = 79525353
stconst.stsctoomanycolss='Cannot assign a matrix with more than 1 column '+
'to an array'


# hash value = 173348348
stconst.stscbadcolcounts='Can only assign a matrix to a virtual matrix if'+
' column counts are equal'


# hash value = 125011244
stconst.stscbadelsizes='Can only assign a matrix to a virtual matrix if e'+
'lement sizes are equal'


# hash value = 83476078
stconst.stscbaddupss='Can only set Duplicates to False in an empty sorted'+
' collection'


# hash value = 19356818
stconst.stsctoomanyfiless='Too many merge files in TStSorter'


# hash value = 42214085
stconst.stscfilecreates='Error creating file'


# hash value = 121241317
stconst.stscfileopens='Error opening file'


# hash value = 200135849
stconst.stscfilewrites='Error writing file (bytes written <> bytes reques'+
'ted)'


# hash value = 81042905
stconst.stscfilereads='Error reading file (bytes read <> bytes requested)'+


# hash value = 87212613
stconst.stscbadstates='TStSorter in wrong state'


# hash value = 28504164
stconst.stscbcdbadformats='Bad BCD format'


# hash value = 1360692
stconst.stscbcdoverflows='BCD larger than 10**64'


# hash value = 220253535
stconst.stscbcddivbyzeros='BCD divide by zero'


# hash value = 111259858
stconst.stscbcdbadinputs='BCD negative input to sqrt, ln, or power'


# hash value = 267841636
stconst.stscbcdbufoverflows='Buffer overflow in FormatBcd'


# hash value = 195693535
stconst.stscnoverinfos='File does not contain version info'


# hash value = 86049215
stconst.stscverinfofails='Unable to read version info'


# hash value = 251546044
stconst.stscshellversionerrors='Operation not supported in this version o'+
'f the shell'


# hash value = 81428388
stconst.stscshellfileopsrcerrors='No source files specified'


# hash value = 149289844
stconst.stscshellfileopdsterrors='No destination files specified'


# hash value = 128367797
stconst.stscshellfileopmaperrors='File mapping incomplete'


# hash value = 196008596
stconst.stscshellformaterrors='Format failed'


# hash value = 119188804
stconst.stscshellformatcancels='Format cancelled'


# hash value = 222971028
stconst.stscshellformatnoformats='Drive cannot be formatted'


# hash value = 156020629
stconst.stscshellformatbaddrives='Invalid drive. Drive is not removable'


# hash value = 18058115
stconst.stsctrayiconinvalidoss='Operating system does not support tray ic'+
'ons'


# hash value = 45953774
stconst.stsctrayiconcantadds='Error adding tray icon'


# hash value = 96219998
stconst.stsctrayiconcantdeletes='Error removing tray icon'


# hash value = 148520066
stconst.stsctrayiconerrors='Tray icon error'


# hash value = 95141460
stconst.stscbaddroptargets='Drop target must be a TWinControl descendant'


# hash value = 56336269
stconst.stsccominitfaileds='Cannot initialize COM'


# hash value = 69615844
stconst.stscnopathspecifieds='Destination directory not specified'


# hash value = 179775819
stconst.stscishelllinkerrors='Error creating IShellLink'


# hash value = 8067636
stconst.stscnotshortcuts='File is not a shortcut'


# hash value = 44709525
stconst.stsctrayiconcloses='&Close'


# hash value = 147502133
stconst.stsctrayiconrestores='&Restore'


# hash value = 263098772
stconst.stscinvalidtargetfiles='Cannot create shortcut. Target file does '+
'not exist'


# hash value = 130692686
stconst.stscshellfileopdeletes='Cannot use file mappings in a delete oper'+
'ation'


# hash value = 92453332
stconst.stscshellfilenotfounds='Source file error, file not found'


# hash value = 21196734
stconst.stsctrayiconduplicates='Cannot have more than one StTrayIcon per '+
'application'


# hash value = 267380463
stconst.stscbadverinfokeys='The specified key cannnot be found in version'+
' info'


# hash value = 226003172
stconst.stscimagelistinvalids='ImageList is not assigned'


# hash value = 83799465
stconst.stscinvalidupcacodelens='Invalid code length (must be 11 or 12)'


# hash value = 169975714
stconst.stscinvalidcharacters='Invalid character'


# hash value = 29161026
stconst.stscinvalidcheckcharacters='Invalid check character'


# hash value = 223979865
stconst.stscinvalidupcecodelens='Invalid code length (must be 6)'


# hash value = 79943993
stconst.stscinvalidean8codelens='Invalid code length (must be 7 or 8)'


# hash value = 83799497
stconst.stscinvalidean13codelens='Invalid code length (must be 12 or 13)'


# hash value = 10490297
stconst.stscinvalidsupcodelens='Invalid supplemental code length (must be'+
' 2 or 5)'


# hash value = 241678222
stconst.stscfinbadargs='Invalid argument to financial function'


# hash value = 254500533
stconst.stscfinnoconverges='Function does not converge'


# hash value = 58234206
stconst.stscexpremptys='Empty expression'


# hash value = 133087810
stconst.stscexprbadnums='Error in floating point number'


# hash value = 236687730
stconst.stscexprbadchars='Unknown character'


# hash value = 136216904
stconst.stscexpropndexps='Expected function, number, sign, or ('


# hash value = 11489730
stconst.stscexprnumerics='Numeric error'


# hash value = 44669198
stconst.stscexprbadexps='Invalid expression'


# hash value = 238037863
stconst.stscexpropndovfls='Operand stack overflow'


# hash value = 240845746
stconst.stscexprunkfuncs='Unknown function identifier'


# hash value = 165462436
stconst.stscexprlparexps='Left parenthesis expected'


# hash value = 79610996
stconst.stscexprrparexps='Right parenthesis expected'


# hash value = 153655508
stconst.stscexprcommexps='Comma expected'


# hash value = 61589586
stconst.stscexprdupidents='Duplicate identifier'


# hash value = 241932420
stconst.stscbadencodefmts='Encoding Format Not Supported'


# hash value = 77701524
stconst.stscbadattachments='Attachment Doesn'#39't Exist'


# hash value = 89569863
stconst.stscdupestrings='Duplicate string'


# hash value = 134927245
stconst.stscinstreams='Error in input stream'


# hash value = 84261939
stconst.stscoutofboundss='Index out of string bounds'


# hash value = 197235252
stconst.stscinvalidlengths='Invalid length for POSTNET'


# hash value = 53669572
stconst.stscnoinputfiles='Input file not specified'


# hash value = 251457204
stconst.stscnooutputfiles='Output file not specified'


# hash value = 190781845
stconst.stscinfileerrors='Error opening input file'


# hash value = 71232373
stconst.stscoutfileerrors='Error creating output file'


# hash value = 346165
stconst.stscnames='Name'


# hash value = 368901
stconst.stscsizes='Size'


# hash value = 376933
stconst.stsctypes='Type'


# hash value = 95406836
stconst.stscmodifieds='Modified'


# hash value = 150815091
stconst.stscattributess='Attributes'


# hash value = 77146290
stconst.stscfilefolders='File Folder'


# hash value = 266371426
stconst.stscsystemfolders='System Folder'


# hash value = 92914830
stconst.stscoriginallocs='Original Location'


# hash value = 237661684
stconst.stscdatedeleteds='Date Deleted'


# hash value = 315429
stconst.stscfiles='File'


# hash value = 52297890
stconst.stscinvalidfolders='Invalid folder'


# hash value = 98586633
stconst.stscfolderreadonlys='Cannot create folder: Parent folder is read-'+
'only'


# hash value = 101099326
stconst.stscinvalidsortdirs='Invalid sort direction'


# hash value = 132943060
stconst.stscinsufficientdatas='FileName cannot be empty when RunParameter'+
's is specified'


# hash value = 202476356
stconst.stsccreatefilefaileds='CreateFile failed'


# hash value = 64591028
stconst.stscfilemappingfaileds='CreateFileMapping failed'


# hash value = 188217684
stconst.stsccreateviewfaileds='MapViewOfFile failed'


# hash value = 219491979
stconst.stscbadorigins='Bad origin parameter for call to Seek'


# hash value = 74081909
stconst.stscgetsizefaileds='Error reading size of existing file'


# hash value = 194465116
stconst.stscnilstreams='Buffered/text stream: Attempted to read, write, o'+
'r seek and underlying stream is nil'


# hash value = 222441929
stconst.stscnoseekforreads='Buffered/text stream: Could not seek to the c'+
'orrect position in the underlying stream (for read request)'


# hash value = 208174953
stconst.stscnoseekforwrites='Buffered/text stream: Could not seek to the '+
'correct position in the underlying stream (for write request)'


# hash value = 124129581
stconst.stsccannotwrites='Buffered/text stream: Could not write the entir'+
'e buffer to the underlying stream'


# hash value = 206779682
stconst.stscbadterminators='Text stream: Case statement was used with a b'+
'ad value of LineTerminator'


# hash value = 26779955
stconst.stscbadlinelengths='Text stream: Length of a fixed line must be b'+
'etween 1 and 4096 bytes'


# hash value = 101892025
stconst.stsccannotsetsizes='Buffered/text stream: Cannot set the size of '+
'the underlying stream (needs OnSetStreamSize event)'


# hash value = 234744158
stconst.stscunknownerrors='Unknown error creating a pattern token'


# hash value = 48182883
stconst.stscexpandingclasss='Problem in expanding character class'


# hash value = 27432882
stconst.stscalternationfollowsclosures='Alternation cannot immediately fo'+
'llow a closure marker'


# hash value = 195023731
stconst.stscunbalancedparenss='Unbalanced nesting parentheses'


# hash value = 27155893
stconst.stscfollowingclosures='Closure cannot immediately follow BegOfLin'+
'e, EndOfLine or another closure'


# hash value = 196895006
stconst.stscpatternerrors='Error detected near end of pattern'


# hash value = 115158658
stconst.stscunbalancedtags='Unbalanced tag marker'


# hash value = 23645332
stconst.stscnopatternss='No Match, Replace, or SelAvoid Patterns defined'


# hash value = 3843182
stconst.stscpatterntoolarges='Pattern exceeds MaxPatLen'


# hash value = 220633236
stconst.stscstreamsnils='Input and/or output stream is not assigned'


# hash value = 83035021
stconst.stscintextstreamerrors='Error creating internal input text stream'+


# hash value = 39646861
stconst.stscouttextstreamerrors='Error creating internal output text stre'+
'am'


# hash value = 139941721
stconst.stscclosuremaybeemptys='A * or + operand could be empty'


# hash value = 19580949
stconst.stscoutfiledeletes='Error deleting old previous file'


# hash value = 221803748
stconst.stscinfilenotfounds='Input file not found'


# hash value = 43996237
stconst.stscreinfileerrors='Error creating internal text stream'


# hash value = 71232373
stconst.stscoutfilecreates='Error creating output file'


# hash value = 64399973
stconst.stscnetnomanualcreates='Can'#39't manually create an object of th'+
'is type'


# hash value = 200393634
stconst.stscnetunknownerrors='Unknown network error'


# hash value = 55711252
stconst.stscnetgroupnotspecifieds='Local or global group not specified'


# hash value = 43980517
stconst.stscnetdatespecifiedoutofranges='Date specified out or range'


# hash value = 182837442
stconst.stscnetinvalidparameters='Invalid parameter'


# hash value = 252199524
stconst.stscnetinvaliditemtypes='Invalid item type for this method'


# hash value = 37074259
stconst.stscstatbadcounts='Unequal or bad counts of array elements'


# hash value = 182837442
stconst.stscstatbadparams='Invalid parameter'


# hash value = 73756457
stconst.stscstatbaddatas='Invalid data point in array'


# hash value = 260111205
stconst.stscstatnoconverges='no convergence in numerical routine'


# hash value = 13641
stconst.stscworddelimiterss='219'


# hash value = 13648
stconst.stscinvalidslentrys='220'


# hash value = 13649
stconst.stscbadstreams='221'

