--------------------------------------------------------------------------------
                     Visual CAPTCHA component for Lazarus
--------------------------------------------------------------------------------

Description
-----------

The component TCaptchaLabel descends from TGraphicControl and contains its own 
drawing routine. Just place it on the form and use it. It displays a random 
string with slanted characters and overlaid lines. 

The method Verify() checks whether a user-provided string matches the 
captcha string and returns true.

There are several properties to define its behaviour:

* NumChars: Number of characters in the captcha

* NumLines: Number of lines drawn over the captcha

* Font1, Font2: two fonts to be mixed within the captcha randomly

* MaxAngle: maximum rotation angle for the characters which are rotated by a 
  random angle between -MaxAngle and +MaxAngle
  
* Color: the background color of the area of the control covered by the captcha. 
  Character and line colors are selected such that a minimum brightness difference 
  to the background color is achieved.
  
* Options: This is a set of the following options which can be combined:
  * coAlphaUpper: Use uppercase characters as defined by the the UppercaseChars string
  * coAlphaLower: Use lowercase characters as defined by the LowercaseChars string
  * coNumeric: Use numeric characters as defined by the NumericChars string 
    (the characters which are hard to distinguish are skipped, 
    zero vs uppercase O, lowercase L vs upper case I)
  * coCustom: Use special characters as defined by the CustomChars string
  * coRotated: Characters are rotated
  * coFont1: Font1 is used
  * coFont2: Font2 is used
  * coLines: Lines are drawn over the captcha
  
* NewCaptchaEvent: Enumerated property for how to quickly select of a new captcha 
  string at runtime:
  * nceNone: deactivated; captcha can only be changed by code.
  * nceClick: a new captcha is created when the user clicks on the control
  * nceDblClick: a new captcha is created when the user double-clicks on the control.


Installation
------------

* Load the package file captcha_pkg.lpk into the Lazarus Package Editor and 
  click "Use" > "Install" to rebuild the Lazarus IDE. When Lazarus restarts you 
  find the new component in the palette "Misc".


License
-------

LGPL with linking exception, like the Lazarus LCL. 
See the file COPYING.modifiedLGPL.txt, included in the Lazarus distribution, 
for details about the license.
