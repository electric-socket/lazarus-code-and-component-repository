The images in this folder are created by icons8.com; they are not modified in
any way (except renaming).

License of icons8.com (https://icons8.com/license):
"The icons are free for personal use and also free for commercial use, but we 
require linking to our web site. We distribute them under the license called 
Creative Commons Attribution-NoDerivs 3.0 Unported."