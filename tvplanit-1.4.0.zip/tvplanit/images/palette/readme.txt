This folder contains the palette icons of the TurboPower VisualPlanIt components.
The icons with appended _150 and _200 are magnifited with respect to the
icons without appended number by factors 150% and 200%, respectively; they are 
used for screens at higher resolutions.

The icons are created from several gimp source files in the ccr directory
image_sources/ccr/components/tvplanit; they are based on selected images taken 
from the FatCow icon collection (http://www.fatcow.com/free-icons, license 
Creative Commons Attribution 3.0). Some images are modified (upscaled, recolored,
etc).
