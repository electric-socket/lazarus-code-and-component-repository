
# hash value = 47539321
vpsr.rsnonestr='(None)'


# hash value = 89
vpsr.rsyes='Y'


# hash value = 78
vpsr.rsno='N'


# hash value = 84
vpsr.rstrue='T'


# hash value = 70
vpsr.rsfalse='F'


# hash value = 1513
vpsr.rstallshortchars='Wy'


# hash value = 78392485
vpsr.rsdelete='Delete'


# hash value = 101276734
vpsr.rsnotdoneyet='This feature is not implemented at this time.'


# hash value = 161288734
vpsr.rsnotimersavail='No Window'#39's timers are available.'


# hash value = 52384030
vpsr.rsbadtriggerhandle='Invalid trigger handle.'


# hash value = 221393838
vpsr.rseditingitems='Folder Items Editor.'


# hash value = 228226782
vpsr.rseditingfolders='Folder Editor.'


# hash value = 244823822
vpsr.rsexclusiveeventconflict='Conflicts with another exclusive event.'


# hash value = 115041950
vpsr.rsbackwardtimeserror='The end time cannot precede the start time.'


# hash value = 114994126
vpsr.rsdbposterror='Error posting data to the database.'


# hash value = 68616942
vpsr.rsmonthconverterror='Error converting the month number.'


# hash value = 119016222
vpsr.rsinvalidday='Error: Invalid Day.'


# hash value = 25210894
vpsr.rsinvaliddate='Error: Invalid Date.'


# hash value = 162004414
vpsr.rsinvalidmonth='Error: Invalid Month.'


# hash value = 200154286
vpsr.rsinvalidmonthname='Error: Invalid Month Name.'


# hash value = 26575422
vpsr.rsinvalidyear='Error: Invalid Year.'


# hash value = 206422654
vpsr.rsdayisrequired='Error: Day is required.'


# hash value = 102296718
vpsr.rsmonthisrequired='Error: Month Is Required.'


# hash value = 120839614
vpsr.rsyearisrequired='Error: Year is required.'


# hash value = 84678670
vpsr.rsnameisrequired='Error: Name cannot be empty.'


# hash value = 153122894
vpsr.rsfailtocreatetask='Error: Failure while creating Task.'


# hash value = 56868094
vpsr.rsfailtocreateevent='Error: Failure while creating Event.'


# hash value = 188999982
vpsr.rsfailtocreatecontact='Error: Failure while creating Contact.'


# hash value = 167095118
vpsr.rsfailtocreateresource='Error: Failure while creating Resource.'


# hash value = 77244078
vpsr.rsduplicateresource='Error: Duplicate Resource.'


# hash value = 210786798
vpsr.rsinvalidtablespecified='Error: Invalid table specified.'


# hash value = 10260608
vpsr.rsunabletoopen='Error: Unable to open '


# hash value = 109972192
vpsr.rssqlupdateerror='Error: Unable to update '


# hash value = 168489204
vpsr.rsphonetypelabel1='Assistant'


# hash value = 137528075
vpsr.rsphonetypelabel2='Callback'


# hash value = 18818
vpsr.rsphonetypelabel3='Car'


# hash value = 174352409
vpsr.rsphonetypelabel4='Company'


# hash value = 325173
vpsr.rsphonetypelabel5='Home'


# hash value = 104286328
vpsr.rsphonetypelabel6='Home Fax'


# hash value = 321422
vpsr.rsphonetypelabel7='ISDN'


# hash value = 88444965
vpsr.rsphonetypelabel8='Mobile'


# hash value = 5680834
vpsr.rsphonetypelabel9='Other'


# hash value = 247732776
vpsr.rsphonetypelabel10='Other Fax'


# hash value = 5668290
vpsr.rsphonetypelabel11='Pager'


# hash value = 126892233
vpsr.rsphonetypelabel12='Primary'


# hash value = 5798655
vpsr.rsphonetypelabel13='Radio'


# hash value = 5948104
vpsr.rsphonetypelabel14='Telex'


# hash value = 161237204
vpsr.rsphonetypelabel15='TTY/TDD'


# hash value = 386699
vpsr.rsphonetypelabel16='Work'


# hash value = 109922664
vpsr.rsphonetypelabel17='Work Fax'


# hash value = 211830835
vpsr.rscategorylabel1='Business'


# hash value = 170903027
vpsr.rscategorylabel2='Clients'


# hash value = 80232505
vpsr.rscategorylabel3='Family'


# hash value = 211443996
vpsr.rscategorylabel4='Personal'


# hash value = 5680834
vpsr.rscategorylabel5='Other'


# hash value = 230414086
vpsr.rsweekof='Week of'


# hash value = 184118152
vpsr.rsthrough='Through'


# hash value = 95177353
vpsr.rssunday='Sunday'


# hash value = 88492681
vpsr.rsmonday='Monday'


# hash value = 196909785
vpsr.rstuesday='Tuesday'


# hash value = 189581113
vpsr.rswednesday='Wednesday'


# hash value = 264871721
vpsr.rsthursday='Thursday'


# hash value = 81328777
vpsr.rsfriday='Friday'


# hash value = 146575129
vpsr.rssaturday='Saturday'


# hash value = 23230
vpsr.rsasunday='Sun'


# hash value = 21598
vpsr.rsamonday='Mon'


# hash value = 23477
vpsr.rsatuesday='Tue'


# hash value = 23988
vpsr.rsawednesday='Wed'


# hash value = 23285
vpsr.rsathursday='Thu'


# hash value = 19849
vpsr.rsafriday='Fri'


# hash value = 22916
vpsr.rsasaturday='Sat'


# hash value = 83
vpsr.rslsunday='S'


# hash value = 77
vpsr.rslmonday='M'


# hash value = 84
vpsr.rsltuesday='T'


# hash value = 87
vpsr.rslwednesday='W'


# hash value = 84
vpsr.rslthursday='T'


# hash value = 70
vpsr.rslfriday='F'


# hash value = 83
vpsr.rslsaturday='S'


# hash value = 349765
vpsr.rsnone='None'


# hash value = 4882489
vpsr.rsdaily='Daily'


# hash value = 98288185
vpsr.rsweekly='Weekly'


# hash value = 46251129
vpsr.rsmonthlybyday='Monthly By Day'


# hash value = 203147141
vpsr.rsmonthlybydate='Monthly By Date'


# hash value = 186898793
vpsr.rsyearlybyday='Yearly By Day'


# hash value = 37590549
vpsr.rsyearlybydate='Yearly By Date'


# hash value = 78424925
vpsr.rscustom='Custom'


# hash value = 67488403
vpsr.rsminutes='Minutes'


# hash value = 5205139
vpsr.rshours='Hours'


# hash value = 305411
vpsr.rsdays='Days'


# hash value = 264862193
vpsr.rspermanent='This operation cannot be undone!'


# hash value = 223961631
vpsr.rsfromcontactlist='from your list of contacts?'


# hash value = 2020142
vpsr.rscontactpopupadd='Add Contact...'


# hash value = 169779438
vpsr.rscontactpopupedit='Edit Contact...'


# hash value = 4463006
vpsr.rscontactpopupdelete='Delete Contact...'


# hash value = 99241151
vpsr.rsfromschedule='from your schedule?'


# hash value = 143382623
vpsr.rsfromtasklist='from your task list?'


# hash value = 181307230
vpsr.rstaskpopupadd='Add Task...'


# hash value = 238217054
vpsr.rstaskpopupedit='Edit Task...'


# hash value = 111510782
vpsr.rstaskpopupdelete='Delete Task...'


# hash value = 144900000
vpsr.rstasktitleresource='Task List - '


# hash value = 164989476
vpsr.rstasktitlenoresource='Task List'


# hash value = 5986953
vpsr.rsmonthpopuptoday='Today'


# hash value = 106375512
vpsr.rsmonthpopupnextmonth='Next Month'


# hash value = 228550168
vpsr.rsmonthpopupprevmonth='Previous Month'


# hash value = 258322242
vpsr.rsmonthpopupnextyear='Next Year'


# hash value = 198781874
vpsr.rsmonthpopupprevyear='Previous Year'


# hash value = 148837838
vpsr.rsweekpopupadd='Add Event...'


# hash value = 118822286
vpsr.rsweekpopupedit='Edit Event...'


# hash value = 244174606
vpsr.rsweekpopupdelete='&Delete Event...'


# hash value = 222118117
vpsr.rsweekpopupnav='Change Date'


# hash value = 5986953
vpsr.rsweekpopupnavtoday='Today'


# hash value = 258314107
vpsr.rsweekpopupnavnextweek='Next Week'


# hash value = 198773643
vpsr.rsweekpopupnavprevweek='Previous Week'


# hash value = 106375512
vpsr.rsweekpopupnavnextmonth='Next Month'


# hash value = 228550168
vpsr.rsweekpopupnavprevmonth='Previous Month'


# hash value = 258322242
vpsr.rsweekpopupnavnextyear='Next Year'


# hash value = 198781874
vpsr.rsweekpopupnavprevyear='Previous Year'


# hash value = 198817765
vpsr.rsprintprvprevpage='Previous Page'


# hash value = 258290453
vpsr.rsprintprvnextpage='Next Page'


# hash value = 174176069
vpsr.rsprintprvfirstpage='First Page'


# hash value = 174404949
vpsr.rsprintprvlastpage='Last Page'


# hash value = 148837838
vpsr.rsdaypopupadd='Add Event...'


# hash value = 118822286
vpsr.rsdaypopupedit='Edit Event...'


# hash value = 244281102
vpsr.rsdaypopupdelete='Delete Event...'


# hash value = 222118117
vpsr.rsdaypopupnav='Change Date'


# hash value = 5986953
vpsr.rsdaypopupnavtoday='Today'


# hash value = 105291479
vpsr.rsdaypopupnavtomorrow='Tomorrow'


# hash value = 179098953
vpsr.rsdaypopupnavyesterday='Yesterday'


# hash value = 217468873
vpsr.rsdaypopupnavnextday='Next Day'


# hash value = 62752649
vpsr.rsdaypopupnavprevday='Previous Day'


# hash value = 258314107
vpsr.rsdaypopupnavnextweek='Next Week'


# hash value = 198773643
vpsr.rsdaypopupnavprevweek='Previous Week'


# hash value = 106375512
vpsr.rsdaypopupnavnextmonth='Next Month'


# hash value = 228550168
vpsr.rsdaypopupnavprevmonth='Previous Month'


# hash value = 258322242
vpsr.rsdaypopupnavnextyear='Next Year'


# hash value = 198781874
vpsr.rsdaypopupnavprevyear='Previous Year'


# hash value = 5986953
vpsr.rshinttoday='Today'


# hash value = 105291479
vpsr.rshinttomorrow='Tomorrow'


# hash value = 179098953
vpsr.rshintyesterday='Yesterday'


# hash value = 258314107
vpsr.rshintnextweek='Next Week'


# hash value = 198773643
vpsr.rshintprevweek='Previous Week'


# hash value = 111192878
vpsr.rsposition='Position'


# hash value = 174352409
vpsr.rscompany='Company'


# hash value = 5966629
vpsr.rstitle='Title'


# hash value = 75642876
vpsr.rsemail='E-Mail'


# hash value = 174873561
vpsr.rscountry='Country'


# hash value = 145482249
vpsr.rscategory='Category'


# hash value = 5597891
vpsr.rsnotes='Notes'


# hash value = 212556689
vpsr.rscustom1='Custom 1'


# hash value = 212556690
vpsr.rscustom2='Custom 2'


# hash value = 212556691
vpsr.rscustom3='Custom 3'


# hash value = 212556692
vpsr.rscustom4='Custom 4'


# hash value = 1339
vpsr.rsokbtn='OK'


# hash value = 77089212
vpsr.rscancelbtn='Cancel'


# hash value = 44709525
vpsr.rsclosebtn='&Close'


# hash value = 45584468
vpsr.rsprintbtn='&Print'


# hash value = 95467380
vpsr.rsuntitled='Untitled'


# hash value = 259246484
vpsr.rsselectasound='Select A Sound'


# hash value = 23760546
vpsr.rssoundfinder='Sound Finder'


# hash value = 197155716
vpsr.rsdefaultsound='Use the default sound'


# hash value = 5033044
vpsr.rsdlgeventedit='Event'


# hash value = 1264948
vpsr.rsappointmentgroupbox='Appointment'


# hash value = 194035674
vpsr.rsdescriptionlbl='Subject:'


# hash value = 180232266
vpsr.rscategorylbl='Category:'


# hash value = 100690714
vpsr.rsstarttimelbl='Start Time:'


# hash value = 106614730
vpsr.rsendtimelbl='End Time:'


# hash value = 205545794
vpsr.rsalarmset='&Reminder'


# hash value = 264355450
vpsr.rsrecurringlbl='Appointment Recurrence:'


# hash value = 36863562
vpsr.rsintervallbl='Interval (days):'


# hash value = 226695114
vpsr.rsrecurrenceendslbl='Repeat Until:'


# hash value = 56788084
vpsr.rsalldayevent='&All Day Event'


# hash value = 89566314
vpsr.rsnoteslbl='Notes:'


# hash value = 174434276
vpsr.rsdlgcontactedit='Contact'


# hash value = 5538698
vpsr.rsnamelbl='Name:'


# hash value = 95466122
vpsr.rstitlelbl='Title:'


# hash value = 179883546
vpsr.rsaddresslbl='Address:'


# hash value = 4852682
vpsr.rscitylbl='City:'


# hash value = 95062666
vpsr.rsstatelbl='State:'


# hash value = 113622378
vpsr.rscountrylbl='Country:'


# hash value = 38419338
vpsr.rszipcodelbl='Zip Code:'


# hash value = 105283946
vpsr.rscompanylbl='Company:'


# hash value = 168473466
vpsr.rspositionlbl='Position:'


# hash value = 1874375
vpsr.rsdlgprintpreview='Print Preview'


# hash value = 370843
vpsr.rsdlgtaskedit='Task'


# hash value = 122339642
vpsr.rsduedate='Due Date:'


# hash value = 212338634
vpsr.rsdetails='Details:'


# hash value = 13695557
vpsr.rscomplete='Task complete'


# hash value = 40210149
vpsr.rsdaysoverdue=' Days overdue'


# hash value = 145739758
vpsr.rscreatedon='Created on'


# hash value = 135078526
vpsr.rscompletedon='Completed on'


# hash value = 205541186
vpsr.rsreminder='Reminder'


# hash value = 178691121
vpsr.rsoverdue='OVERDUE!'


# hash value = 30317466
vpsr.rssnoozecaption='Click &Snooze to be reminded again in:'


# hash value = 194035674
vpsr.rssubjectcaption='Subject:'


# hash value = 89566314
vpsr.rsnotescaption='Notes:'


# hash value = 185221635
vpsr.rsdismissbtn='&Dismiss'


# hash value = 195389221
vpsr.rssnoozebtn='&Snooze'


# hash value = 201833693
vpsr.rsopenitembtn='&Open Item'


# hash value = 67501459
vpsr.rs5minutes='5 Minutes'


# hash value = 67537043
vpsr.rs10minutes='10 Minutes'


# hash value = 67538323
vpsr.rs15minutes='15 Minutes'


# hash value = 67545235
vpsr.rs30minutes='30 Minutes'


# hash value = 67550611
vpsr.rs45minutes='45 Minutes'


# hash value = 53802690
vpsr.rs1hour='1 Hour'


# hash value = 72314019
vpsr.rs2hours='2 Hours'


# hash value = 89091235
vpsr.rs3hours='3 Hours'


# hash value = 105868451
vpsr.rs4hours='4 Hours'


# hash value = 122645667
vpsr.rs5hours='5 Hours'


# hash value = 139422883
vpsr.rs6hours='6 Hours'


# hash value = 156200099
vpsr.rs7hours='7 Hours'


# hash value = 172977315
vpsr.rs8hours='8 Hours'


# hash value = 3361417
vpsr.rs1days='1 Day'


# hash value = 54831363
vpsr.rs2days='2 Days'


# hash value = 55879939
vpsr.rs3days='3 Days'


# hash value = 56928515
vpsr.rs4days='4 Days'


# hash value = 57977091
vpsr.rs5days='5 Days'


# hash value = 59025667
vpsr.rs6days='6 Days'


# hash value = 53861307
vpsr.rs1week='1 Week'


# hash value = 228550168
vpsr.rscalendarprevmonth='Previous Month'


# hash value = 106375512
vpsr.rscalendarnextmonth='Next Month'


# hash value = 198781874
vpsr.rscalendarprevyear='Previous Year'


# hash value = 258322242
vpsr.rscalendarnextyear='Next Year'


# hash value = 5986953
vpsr.rscalendartoday='Today'


# hash value = 93113492
vpsr.rscalendarrevert='Revert'


# hash value = 5986953
vpsr.rscalendarpopuptoday='Today'


# hash value = 106375512
vpsr.rscalendarpopupnextmonth='Next Month'


# hash value = 228550168
vpsr.rscalendarpopupprevmonth='Previous Month'


# hash value = 258322242
vpsr.rscalendarpopupnextyear='Next Year'


# hash value = 198781874
vpsr.rscalendarpopupprevyear='Previous Year'


# hash value = 93113492
vpsr.rscalendarpopuprevert='Revert'


# hash value = 212630100
vpsr.sienotinstalled='Cannot open WININET, Microsoft IE required'


# hash value = 253544032
vpsr.sopenfilefailed='Unable to open file '


# hash value = 117221412
vpsr.sfilenotfound='File %s could not be found'


# hash value = 76314325
vpsr.sallocsrcmemfailed='Unable to allocate memory for XML source'


# hash value = 100728100
vpsr.shttpreadreqfailed='Http read request failed'


# hash value = 75696565
vpsr.shttpdatanotavail='Http data not available'


# hash value = 148414788
vpsr.shttpreqsendfailed='Unable to send http request'


# hash value = 154619684
vpsr.shttpreqopenfailed='Unable to open http request'


# hash value = 143764238
vpsr.sinetconnectfailed='Unable to make Internet connection'


# hash value = 32342212
vpsr.sinetopenfailed='Unable to open Internet'


# hash value = 109814542
vpsr.sinvalidftploc='Invalid ftp location'


# hash value = 160070569
vpsr.sinvalidftpdir='Invalid ftp directory'


# hash value = 45546788
vpsr.sftpreadreqfailed='Ftp read request failed'


# hash value = 71854517
vpsr.sftpdatanotavail='Ftp data not available'


# hash value = 258424821
vpsr.sftpopenfilefailed='Unable to open ftp file'


# hash value = 35253107
vpsr.sftpputfilefailed='Could not save file via ftp to %s'


# hash value = 175849584
vpsr.ssrcloadfailed='Unable to load source '


# hash value = 57976162
vpsr.sinvalidmemptr='Invalid memory Pointer'


# hash value = 231806483
vpsr.sfmterrormsg='Line: %d Col: %d Error: %s'


# hash value = 145571651
vpsr.sindexoutofbounds='ERROR INDEX OUT OF BOUNDS'


# hash value = 84259344
vpsr.sexpmarkupdecl='Expected markup declaration, but found: '


# hash value = 230425296
vpsr.sillattrtype='Illegal attribute type: '


# hash value = 18220816
vpsr.sillattrdefkeyw='Illegal keyword for attribute default value: '


# hash value = 56058800
vpsr.ssysidmissing='System identifier missing '


# hash value = 190353936
vpsr.sextmodifmissing='External modifier missing: '


# hash value = 263225829
vpsr.sillcondsectstart='Conditional section must begin with INCLUDE or IG'+
'NORE'


# hash value = 14663744
vpsr.sbadsepinmodel='Bad separator in content model: '


# hash value = 29021872
vpsr.sexpcommentorcdata='Expected comment or CDATA section '


# hash value = 135168176
vpsr.sunexpectedeof='Unexpected end of file '


# hash value = 141533008
vpsr.smismatchendtag='Mismatched end tag: '


# hash value = 12051765
vpsr.sillcharinref='Illegal character in reference'


# hash value = 132797168
vpsr.sundeclaredentity='Reference to undeclared entity: '


# hash value = 23714256
vpsr.sexpectedstring='Expected String: '


# hash value = 23208656
vpsr.sspaceexpectedat='Whitespace expected at byte '


# hash value = 99478656
vpsr.sunexpendofinput='End of input while looking for delimiter: '


# hash value = 83723191
vpsr.squoteexpected='Expected " or '#39

# hash value = 98409107
vpsr.sinvalidxmlversion='XMLPartner does not support XML specification gr'+
'eater than %s'


# hash value = 168031582
vpsr.sunablecreatestr='Unable to create stream for input.'


# hash value = 220733696
vpsr.sinvalidname='Invalid XML name: '


# hash value = 101287188
vpsr.sinvalidcommenttext='Invalid comment text'


# hash value = 120830862
vpsr.scommentbeforexmldecl='Document cannot start with a comment if it al'+
'so contains an XML declaration'


# hash value = 223040718
vpsr.sinvalidcdatasection='Invalid characters in CDATA section'


# hash value = 92987879
vpsr.sredefinedattr='Attributes cannot be redefined in a start tag'


# hash value = 249132960
vpsr.scircularentref='Circular reference to: '


# hash value = 177029312
vpsr.sinvattrchar='Invalid character in attribute value: '


# hash value = 89182192
vpsr.sinvpcdata='Invalid characters in element'#39's character data: '


# hash value = 266616484
vpsr.sdataaftervaldoc='There is invalid data after valid XML document'


# hash value = 251682990
vpsr.snointconditional='Conditional sections not allowed in internal subs'+
'et of document type declaration'


# hash value = 241136016
vpsr.snotationnotdeclared='Notation not declared: '


# hash value = 41663008
vpsr.sinvpubidchar='Invalid PublicID character: '


# hash value = 200364318
vpsr.snondatainpedecl='NDATA not allowed in parameter entity declaration'


# hash value = 143094631
vpsr.sinvstandaloneval='Standalone value must equal '#39'yes'#39' or '#39+
'no'#39

# hash value = 232508640
vpsr.sinvencname='Invalid encoding declaration: '


# hash value = 208760336
vpsr.sinvvernum='Invalid XML version number: '


# hash value = 127703696
vpsr.sinventityvalue='Invalid character in entity value: '


# hash value = 109631936
vpsr.snocommentinmarkup='Comments can not be placed within other markup'


# hash value = 208762004
vpsr.snopeinintdtd='Parameter entities not allowed in DTD internal subset'+


# hash value = 163448628
vpsr.sxmldecnotatbeg='The XML declaration must appear before the first el'+
'ement'


# hash value = 233823776
vpsr.sinvalidelementname='Invalid element name: '


# hash value = 231694352
vpsr.sbadparamentnesting='Parameter-entity text must be properly nested: '+


# hash value = 113027358
vpsr.sinvalidcharencoding='Invalid character encoding specified.'


# hash value = 130745646
vpsr.sattrnotnum='Attribute %s of element %s does not have an integer val'+
'ue.'


# hash value = 100807091
vpsr.sunknownaxis='Unknown axis specifier: %s'


# hash value = 225980260
vpsr.sinvalidxmlchar='Invalid XML Character found'


# hash value = 135935175
vpsr.sinvalidbechar='Invalid (big-endian) UTF-16 character encoding'


# hash value = 94102807
vpsr.sinvalidlechar='Invalid (little-endian) UTF-16 character encoding'


# hash value = 256797885
vpsr.sbadutf8char='Badly formed UTF-8 character in stream'


# hash value = 253773773
vpsr.serrendofdocument='Unexpected end of document stream'


# hash value = 2450625
vpsr.sucs_isoconverterr='Cannot convert UCS-4 character to ISO-8859-1'


# hash value = 262680790
vpsr.sucs_u16converterr='Cannot convert UCS-4 character to UTF-16'


# hash value = 167412488
vpsr.sucs_u8convererr='Cannot convert UCS-4 character to UTF-8'


# hash value = 219423621
vpsr.rsoutofrange='Out of range'


# hash value = 34660356
vpsr.rsnotsupported='not supported'


# hash value = 31331829
vpsr.rsneedelementname='Please supply an Element Name'


# hash value = 10200635
vpsr.rsneedformatname='FormatName cannot be blank'


# hash value = 57697009
vpsr.rsprtcontrolowner='Print controller is not owned by a TVpControlLink'+
'!'


# hash value = 141019168
vpsr.rsbadprintformat='Invalid print format '


# hash value = 86033632
vpsr.rsbaditemtype='Invalid item type '


# hash value = 180683348
vpsr.rsbadmeasurement='Invalid measurement'


# hash value = 169471620
vpsr.rsownernotwinctrl='Owner must be a TWinControl descendent'


# hash value = 136754107
vpsr.rsnocontrollink='Component must be linked to a TVpControlLink'


# hash value = 96335620
vpsr.rsnoprintformats='No print formats have been defined'


# hash value = 172789716
vpsr.rsnocanvas='TCanvas not assigned'


# hash value = 215458782
vpsr.rsnolocalizationfile='Localization file not found.'


# hash value = 199361424
vpsr.rscategorydesc0='Category 0'


# hash value = 199361425
vpsr.rscategorydesc1='Category 1'


# hash value = 199361426
vpsr.rscategorydesc2='Category 2'


# hash value = 199361427
vpsr.rscategorydesc3='Category 3'


# hash value = 199361428
vpsr.rscategorydesc4='Category 4'


# hash value = 199361429
vpsr.rscategorydesc5='Category 5'


# hash value = 199361430
vpsr.rscategorydesc6='Category 6'


# hash value = 199361431
vpsr.rscategorydesc7='Category 7'


# hash value = 199361432
vpsr.rscategorydesc8='Category 8'


# hash value = 199361433
vpsr.rscategorydesc9='Category 9'


# hash value = 109668078
vpsr.rseditprintformat='Edit Print Formats...'


# hash value = 134418655
vpsr.rsaddnewresource='No resources have been defined. Would you like to '+
'add one now?'


# hash value = 164397583
vpsr.rsselectresource='No resource has been selected. Would you like to s'+
'elect one now?'

