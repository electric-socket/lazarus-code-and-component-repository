This project in folder "gadgets" demonstrates the "gadgets" of the Visual PlanIt
package: an analog/digital clock and a LED display.
