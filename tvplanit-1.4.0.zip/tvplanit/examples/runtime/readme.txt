This project in folder "runtime" creates VisualPlanit components at runtime. 

It uses a TVpBufDSDatastore, as well as a TVpDayView, TVpWeekView, TVpMonthView,
and a TVpResourceCombo control.