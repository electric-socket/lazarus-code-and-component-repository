This demo shows how a Firebird database can be used for VisualPlanIt. It 
takes advantage of the prebuilt TVpFirefordDatastore.

Login parameters for the created database:
  username: SYSDBA
  password: masterkey

NOTE:
The project creates a new database on the fly using these login parameters.
