This project in folder "navbar" shows how to use the TVpNavBar component of
the TvPlanit package. It demonstrates directly the effect of some properties 
modified at runtime.