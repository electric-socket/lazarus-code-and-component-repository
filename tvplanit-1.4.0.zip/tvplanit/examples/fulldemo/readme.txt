This demo shows many of the possibilities of the Turbo Power VisualPlanIt 
package.

In this example the datastore resides in a datamodule to hide the type of
database connection from the main form.

It can also be used to test translations of strings.
