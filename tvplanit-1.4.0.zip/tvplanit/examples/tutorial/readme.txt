This folder contains the soures of the "getting started" tutorial of the wiki:
http://wiki.freepascal.org/Turbopower_Visual_PlanIt