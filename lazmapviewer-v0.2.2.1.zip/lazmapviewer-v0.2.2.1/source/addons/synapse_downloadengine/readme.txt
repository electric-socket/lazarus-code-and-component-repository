This folder contains the sources of the download engine based on the Synapse
library.

Since the Synapse package (laz_synapse.lpk) does not contain the files needed
for ssl they were copied into this folder to be found for compilation.