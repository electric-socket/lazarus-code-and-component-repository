***********************
*** bzip2lib ReadMe ***
***********************

About
-----

Unit bzip2lib contains 2 stream classes for BZIP2 compression and decompression.
Class TBzip2CompressStream is for compressing (packing) data to bzip2 format and
class TBzip2DecompressStream is for decompressing (unpacking) data back to its original form.

Unit bzip2lib is collected and edited from 2 unit files in Jcl package,
  JclCompression and bzip2.
The purpose was to make it compile and work with FPC (Free Pascal Compiler).
In the process lots of code with conditional compilation directives were removed 
and also many unit dependencies were removed.


Dependencies
------------

The code uses external bzip2 libraries for its job:
  'bzip2.dll' in Windows
  'libbz2.so.1' in Linux


Usage
-----

Just include unit bzip2lib in the "uses" section.
External bzip2 library must be installed in your machine (see *Dependencies*).
Use TBzip2CompressStream and TBzip2DecompressStream just like any stream,
connecting them to file stream or memory stream if needed.

Note1: I tested this only in Linux. Someone please test it in Windows and other platforms.
       Then this note should be changed as well.

Note2: There is another unit called "bzip2" under fpcsrc/packages/bzip2.
       It contains pure pascal code doing bzip2 decompression.
       It can't compress but on the other hand it doesn't need external libraries.
       I would suggest changing its name to "Bzip2Decompress" or something similar to make
       the difference clear. I named this unit as bzip2lib to indicate it depends on libraries.
       After any changes again this note should be changed.


Example code
------------

There is an example program "bzip2test" under Example directory.
It takes a file name as command line parameter. It should be a text file here
  because the program uses TStringList as a temporary storage for it.
Then it compresses the file and saves it as "Compressed.bz2".
Then it decompresses the compressed file again and saves the result as "Decompressed.txt".
If everything works then "Decompressed.txt" should be identical with the original file.


License
-------

This code is licensed under the same terms as Jcl library.


Contact
-------

Author: Juha Manninen <juha dot manninen (at) phnet dot fi>
       + the original authors from Jcl code.
