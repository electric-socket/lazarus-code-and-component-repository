This are the orginal files of the JvXP components.
All are version 11400 of JVCL version 3.33 released 
in september 2007.

The only component converted to lazarus was XPBar.
I wasn't too dificult after all but still dont tested
on linux, just Windows XP SP2.

Sergio Samayoa.
23.09.2007
