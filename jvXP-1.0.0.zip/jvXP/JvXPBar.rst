
# hash value = 95466868
jvxpbar.rsuntitled='untitled'


# hash value = 180693833
jvxpbar.rsuntitledfmt='(%s %d)'


# hash value = 206744697
jvxpbar.rshintshortcutfmt='%s (%s)'

