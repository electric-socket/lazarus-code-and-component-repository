mbColorLib is a comprehensive library with more than 30 components for 
color selection in several color models (RGB, CYMK, HSV, HSL, CIE-Lab). 
The components can be combined to create numerous new tools and color dialogs. 

License:
see Readme.rtf