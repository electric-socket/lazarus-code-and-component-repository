15.10.03
ver. 4.01
for Delphi 4-7 and C++Builder 4-6

========================================================================
             The Open QBuilder for Delphi and C++Builder
========================================================================

The Open QBuilder (OQBuilder) is a simple visual query builder component set
for Delphi and C++Builder developers. 
Open QBuilder is the next generation of well-known QBuilder.

Please, read more about OQBuilder's in the short documentation file: 
/Doc/oqbuilder.html

Please, check the /Doc/history.txt file to read about the latest changes and 
additions.

The latest version of OQBuilder and additional components you can find on
OQBuilder home page at:
http://www.fast-report.com/en/qbuilder.php

========================================================================

About using OQBuilder in your projects
--------------------------------------

Open QBuilder and another my tools and components are freeware. 
I can't provide the technical support for these tools, but you have all 
source code and you can modify it without restriction for any non-commercial 
projects. 

Please, let me know if you want to use my software in your commercial projects 
by e-mail: support@fast-report.com 
with tool name in a message subject.

========================================================================

About Author
------------

  Sergey Orlik
  product manager 
  Borland Moscow office
  Russia, CIS and Baltic States

  E-mail: support@fast-report.com
  Home page: 
    http://www.fast-report.com/en/qbuilder.php

========================================================================
Copyright (c) 1996-2003 Sergey Orlik 
Copyright (c) 2003 Fast Reports, Inc
========================================================================

Adapted for Lazarus Zeosdb by Jepafi.
Modified (added SQLDB, IBX from original Open QBuilder) by Reinier Olislagers
See license.txt and source files.