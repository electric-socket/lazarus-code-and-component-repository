TCalendarLite is a light-weight calendar component, a TGraphicControl
descendant which consequently is not dependent on any widgetset.
It is not a fixed-size component, as are most calendars, but will align
and resize as needed.

License: modified LGPL (with linking exception) (the license same as Lazarus)

The palette icon was painted by Roland Hahn. It is freeware and not subject to
any restrictions.
