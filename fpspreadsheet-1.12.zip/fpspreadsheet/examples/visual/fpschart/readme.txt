The fpschart demo shows usage of the TsWorksheetChartSource component for
creating charts from spreadsheet data. 
