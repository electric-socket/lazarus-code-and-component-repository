WikiTableMaker implements an editor for tables to be used in wikis.

Load a spreadsheet file into the worksheet grid, or type in the data needed.
Go to page "code" to see the wiki code. Copy it to the clipboard and paste it
into the wiki source page.

Technically, WikiTableMaker is a moderately stripped-down version of the 
spready demo. The worksheet grid, however, is created at run-time. Therefore, 
it is not necessary to install the laz_fpspreadsheet package to run this 
sample project.

If compiled with Lazarus version you have to accept missing properties in the
lfm file related to SynEdit.
