This demonstrates use of the Lazarus grid component supplied with fpspreadsheet.
It demonstrates only the basics; a more extensive example can be found in the
spready demo.