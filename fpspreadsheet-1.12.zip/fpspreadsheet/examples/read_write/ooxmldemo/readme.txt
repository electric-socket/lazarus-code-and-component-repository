This demo demonstrates how to use fpspreadsheet to write Microsoft OOXML
(new Excel format) .xlsx files.