This demo program reads encrypted xlsx files.

File "encrypted_workbook.xlsx" was encrypted in the File menu of Excel 2007.
The password is "test".

The file "protected_workbook.xlsx" was worksheet-protected in the Inspect
menu of Excel 2007. The password "test" was specified, it is not the password
used for encryption of the file, it is only needed to unlock worksheet protection.