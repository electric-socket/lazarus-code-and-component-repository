/***************************************************************************
                              TTreeviewDlg.pp
                            -------------------
                  Component Library : Dialogs TreeviewDialog
                  Initial Revision  : Thu Mar 22 2007 20:00:00 CAT
                  Last update       : Thu Mar 25 2007 21:15:00 CAT


*****************************************************************************
*                                                                           *
*  This program is distributed in the hope that it will be useful,          *
*  but WITHOUT ANY WARRANTY; without even the implied warranty of           *
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                     *
*                                                                           *
*****************************************************************************

@author(TTreeviewDialog - RJB <rudolf@ananzi.co.za>)
@created(22-Mar-2007)
@lastmod(25-Mar-2007)

  Declares a Treeview Dialog descendant from TCommonDialog that can be
  populated from a dataset or file, returning the text and selected index
  of the selected node in the tree. 

  !!!!!     Requires FCL 1.0 or greater     !!!!!

***************************************************************************/


To use the Treeview dialog, the TTreeviewDialog.Dataset OR 
TTreeviewDialog.Filename properties should be set.  The result of the dataset 
query should look like the following example:

+--------+--------+-----------+--------+-----------+
| Field0 | Field1 | Field2    | Field3 | Field4    |
+--------+--------+-----------+--------+-----------+
| 1      | Fruit  | Citrus    | Orange | Valencia  |
+--------+--------+-----------+--------+-----------+
| 2      | Fruit  | Citrus    | Orange | Navel     |
+--------+--------+-----------+--------+-----------+
| 3      | Fruit  | Citrus    | Lemon  | Lemon     |
+--------+--------+-----------+--------+-----------+
| 4      | Fruit  | Subtropic | Banana | Cavendish |
+--------+--------+-----------+--------+-----------+
| 5      | Fruit  | Subtropic | Banana | Williams  |
+--------+--------+-----------+--------+-----------+

SQL select statement that extracted the above data from four relational tables:

select v.VarietyId,
       p.ProductCode,
       pg.ProductGroupCode,
       t.TypeCode,
       v.VarietyCode

from  Product as p
  join ProductGroup as pg 
    ON p.ProductCode = pg.ProductCode
  join Type as t
    ON pg.ProductGroupCode = t.ProductGroupCode
  join Variety as v
    ON t.TypeCode = v.TypeCode

The first field (Field0) should contain an integer value that will be used as 
the SelectedIndex in the treeview for the items in the last field (Can also 
be null in all instances).  All the upper level items will be assigned a 
SelectedIndex value of zero(0).  For the above resultset, the following 
treeview will be constructed, with the SelectedIndex values in brackets after 
each item.

Fruit(0)
    |
    +--Citrus(0)
    |    |
    |    +--Orange(0)
    |    |    |
    |    |    +--Valencia(1)
    |    |    |
    |    |    +--Navel(2)
    |    |
    |    +--Lemon(0)
    |         |
    |         +--Lemon(3)
    |
    +--Subtropic(0)
         |
         +--Banana(0)
              |
              +--Cavendish(4)
              |
              +--Williams(5)

Alternatively a filename can be supplied to be used to populate the treeview.  All items will be assigned a SelectedIndex value of zero(0) in the case of a file being used.  The file structure should look like follows, using either single spaces or tabs for the indentation:

Fruit
 Citrus
  Orange
   Valencia
   Navel
  Lemon
   Lemon
 Subtropic
  Banana
   Cavendish
   Williams

The above text file layout will produce the same treeview as the query above 
with the exception of the SelectedIndex values.  The selected item's value 
and index is stored in the TTrreviewDialog.SelecetedText and 
TTreeviewDialog.SelectedIndex properties respectively.

