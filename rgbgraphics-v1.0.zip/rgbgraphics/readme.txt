-------------------------------------------------------------------------------
                               RGBGraphics
-------------------------------------------------------------------------------

LazRGBGraphics is a run-time package for fast in memory image processing and 
pixel manipulations (like scan line). The main advantage is direct memory 
access to bitmap pixels with keeping ability to draw bitmap onto canvas without 
any time consuming widgetset memory format converting. 

Details:
https://wiki.freepascal.org/LazRGBGraphics


Installation
------------
This is a run-time package - no need to install. Just open it in 
"Package" > "Open package file (*.lpk)...". This is enough for the IDE to
know the path to the package files. You may click "Compile" to verify
the integrity of the package, but strictly speaking this is not necessary.


Why are there two packages?
---------------------------
Yes, there are two packages, lazrgbgraphics.lpk as well as rgb_graphics.lpk.

lazrgbgraphics is the package by the original author in Lazarus CCR. Pilot Logic
made a different version, and this eventually made it as rgb_graphics into the 
Lazarus Online-Package-Manager.

Both packages have the same content and differ only by their name. Since
they are runtime packages the IDE accepts both of them. This way the risk of
breaking user code is minimized.

For new users, however, it is recommended to use lazrgbgraphics.lpk only 
because the other one may be removed from the installation at some time 
in the future.
