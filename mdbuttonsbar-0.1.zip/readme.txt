  TMDButtonsBar
  A Lazarus component to help Multi Doc Component with ButtonsBar
  This component can be "the start" of one component for titlebar of Multi Docs Application
  Only should be implemented :-)
  
  Copyright (C) 2006 J�nior Gon�alves <hipernetjr@yahoo.com.br> 
  http://lazaruspascal.codigolivre.org.br/portal.php
  
